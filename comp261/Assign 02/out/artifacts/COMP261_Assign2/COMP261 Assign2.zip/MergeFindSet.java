/**
 * Created by drb on 02/04/15.
 */
public class MergeFindSet<T> {


    private class MergeFindSetNode<T> {
        MergeFindSetNode<T> parent;
        int depth;

    }
}
