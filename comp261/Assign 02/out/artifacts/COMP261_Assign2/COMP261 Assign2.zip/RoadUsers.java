/**
 * Created by drb on 31/03/15.
 */
public enum RoadUsers {
    ALLOW_CARS,
    ALLOW_CYCLISTS,
    ALLOW_PEDESTRIANS,
}
